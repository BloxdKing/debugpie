package com.debugpie.hud;

import com.debugpie.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.profiler.ProfilerTiming;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DebugHudRenderer {

    // Dragging state
    private static boolean dragging = false;
    private static int dragOffsetX = 0;
    private static int dragOffsetY = 0;

    private static final int PADDING = 8;
    private static final int BAR_HEIGHT = 4;
    private static final int ROW_HEIGHT = 18;
    private static final int HEADER_HEIGHT = 22;

    public static void render(DrawContext ctx, MinecraftClient client) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.overlayVisible) return;
        if (client.getProfilerResult() == null) return;

        // ─── Gather profiler entries ───
        List<ProfilerEntry> entries = gatherEntries(client, cfg.maxEntries);
        if (entries.isEmpty()) return;

        int panelW = cfg.panelWidth;
        int rowCount = entries.size();
        int panelH = HEADER_HEIGHT + PADDING + rowCount * ROW_HEIGHT + PADDING;

        int x = cfg.posX;
        int y = cfg.posY;

        // ─── Scale ───
        ctx.getMatrices().push();
        ctx.getMatrices().scale(cfg.scale, cfg.scale, 1f);

        // Adjust coords for scale
        int sx = (int)(x / cfg.scale);
        int sy = (int)(y / cfg.scale);

        // ─── Background ───
        drawRoundRect(ctx, sx, sy, panelW, panelH, cfg.backgroundColor, cfg.cornerRadius);

        // ─── Border ───
        if (cfg.borderThickness > 0) {
            drawRoundRectBorder(ctx, sx, sy, panelW, panelH, cfg.borderColor, cfg.cornerRadius, cfg.borderThickness);
        }

        // ─── Title ───
        if (cfg.showTitle) {
            String title = "⬡ PROFILER";
            int titleX = sx + PADDING;
            int titleY = sy + PADDING;
            ctx.drawTextWithShadow(client.textRenderer, title, titleX, titleY, cfg.titleColor);

            // Accent line under title
            ctx.fill(sx + PADDING, sy + HEADER_HEIGHT - 3, sx + panelW - PADDING, sy + HEADER_HEIGHT - 2, cfg.borderColor);
        }

        // ─── Entries ───
        int entryY = sy + HEADER_HEIGHT + PADDING / 2;
        for (ProfilerEntry entry : entries) {
            renderEntry(ctx, client, entry, sx + PADDING, entryY, panelW - PADDING * 2, cfg);
            entryY += ROW_HEIGHT;
        }

        ctx.getMatrices().pop();
    }

    private static void renderEntry(DrawContext ctx, MinecraftClient client,
                                    ProfilerEntry entry, int x, int y,
                                    int width, ModConfig cfg) {
        String label = truncate(entry.name, 18);
        String pct   = String.format("%.1f%%", entry.percentage);

        // Bar
        if (cfg.showBars) {
            int barW = width;
            int barX = x;
            int barY = y + 10;
            // Background bar
            ctx.fill(barX, barY, barX + barW, barY + BAR_HEIGHT, cfg.barBgColor);
            // Filled bar
            int fillW = (int)(barW * entry.percentage / 100.0);
            // Color shifts from barColor toward red as % increases
            int barColor = lerpColor(cfg.barColor, 0xFFE74C3C, (float)(entry.percentage / 100.0));
            ctx.fill(barX, barY, barX + fillW, barY + BAR_HEIGHT, barColor);
        }

        // Label
        ctx.drawTextWithShadow(client.textRenderer, label, x, y, cfg.textColor);

        // Percentage
        if (cfg.showPercent) {
            int pctW = client.textRenderer.getWidth(pct);
            ctx.drawTextWithShadow(client.textRenderer, pct, x + width - pctW, y, cfg.percentColor);
        }
    }

    private static List<ProfilerEntry> gatherEntries(MinecraftClient client, int max) {
        List<ProfilerEntry> result = new ArrayList<>();
        try {
            var profilerResult = client.getProfilerResult();
            if (profilerResult == null) return result;

            List<ProfilerTiming> timings = profilerResult.getTimings("root");
            if (timings == null || timings.isEmpty()) return result;

            double totalMs = timings.stream().mapToDouble(t -> t.time).sum();
            if (totalMs <= 0) return result;

            timings.stream()
                    .filter(t -> !t.name.equals("unspecified"))
                    .sorted(Comparator.comparingDouble((ProfilerTiming t) -> t.time).reversed())
                    .limit(max)
                    .forEach(t -> {
                        double pct = (t.time / totalMs) * 100.0;
                        result.add(new ProfilerEntry(t.name, pct, t.time / 1_000_000.0));
                    });
        } catch (Exception ignored) {}
        return result;
    }

    // ─── Drawing utilities ───

    private static void drawRoundRect(DrawContext ctx, int x, int y, int w, int h, int color, int r) {
        r = Math.min(r, Math.min(w, h) / 2);
        // Fill center
        ctx.fill(x + r, y,     x + w - r, y + h,     color);
        ctx.fill(x,     y + r, x + r,     y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);
        // Corners (approximate with small squares)
        for (int i = 0; i < r; i++) {
            int offset = r - (int)Math.sqrt(r * r - (r - i) * (r - i));
            ctx.fill(x + offset, y + i, x + r, y + i + 1, color);
            ctx.fill(x + w - r, y + i, x + w - offset, y + i + 1, color);
            ctx.fill(x + offset, y + h - i - 1, x + r, y + h - i, color);
            ctx.fill(x + w - r, y + h - i - 1, x + w - offset, y + h - i, color);
        }
    }

    private static void drawRoundRectBorder(DrawContext ctx, int x, int y, int w, int h, int color, int r, int t) {
        // Top / bottom / left / right edges
        ctx.fill(x + r, y,         x + w - r, y + t,         color);
        ctx.fill(x + r, y + h - t, x + w - r, y + h,         color);
        ctx.fill(x,     y + r,     x + t,     y + h - r,     color);
        ctx.fill(x + w - t, y + r, x + w,     y + h - r,     color);
    }

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF, aa = (a >> 24) & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF, ba = (b >> 24) & 0xFF;
        int r = (int)(ar + (br - ar) * t);
        int g = (int)(ag + (bg - ag) * t);
        int bv = (int)(ab + (bb - ab) * t);
        int av = (int)(aa + (ba - aa) * t);
        return (av << 24) | (r << 16) | (g << 8) | bv;
    }

    private static String truncate(String s, int max) {
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }

    public record ProfilerEntry(String name, double percentage, double timeMs) {}
}
