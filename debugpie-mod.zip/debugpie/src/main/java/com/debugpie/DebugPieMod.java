package com.debugpie;

import com.debugpie.config.ModConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DebugPieMod implements ClientModInitializer {

    public static final String MOD_ID = "debugpie";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Keybinding: Toggle overlay visibility
    public static KeyBinding toggleOverlayKey;
    // Keybinding: Open config screen
    public static KeyBinding openConfigKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("DebugPie initializing...");

        // Load config
        ModConfig.load();

        // Register keybindings
        toggleOverlayKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.debugpie.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F4,
                "category.debugpie"
        ));

        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.debugpie.config",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F6,
                "category.debugpie"
        ));

        // Handle keybinding presses
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleOverlayKey.wasPressed()) {
                ModConfig.get().overlayVisible = !ModConfig.get().overlayVisible;
                ModConfig.save();
            }
            if (openConfigKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new com.debugpie.config.ConfigScreen(null));
                }
            }
        });

        // Register HUD renderer
        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register(
                (drawContext, tickDelta) -> com.debugpie.hud.DebugHudRenderer.render(drawContext, client)
        );

        LOGGER.info("DebugPie initialized.");
    }
}
