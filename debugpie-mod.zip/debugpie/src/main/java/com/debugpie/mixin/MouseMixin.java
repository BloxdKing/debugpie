package com.debugpie.mixin;

import com.debugpie.util.DragHandler;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void debugpie$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        Mouse mouse = (Mouse)(Object)this;
        DragHandler.onMouseButton(mouse.getX(), mouse.getY(), button, action);
    }

    @Inject(method = "onCursorPos", at = @At("HEAD"))
    private void debugpie$onCursorPos(long window, double x, double y, CallbackInfo ci) {
        DragHandler.onMouseMove(x, y);
    }
}
