package com.debugpie.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

public class ModConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("debugpie.json");

    private static ModConfig INSTANCE = new ModConfig();

    // --- Visibility ---
    public boolean overlayVisible = true;

    // --- Position ---
    public int posX = 10;
    public int posY = 10;

    // --- Size ---
    public float scale = 1.0f;
    public int panelWidth = 220;

    // --- Colors (ARGB hex as int) ---
    public int backgroundColor = 0xCC0A0A0A;   // Dark near-black
    public int borderColor     = 0xFF2ECC71;   // Emerald green accent
    public int titleColor      = 0xFFFFFFFF;   // White
    public int textColor       = 0xFFCCCCCC;   // Light grey
    public int barColor        = 0xFF2ECC71;   // Emerald green
    public int barBgColor      = 0xFF1A1A1A;   // Dark bar background
    public int percentColor    = 0xFFFFFFFF;   // Percentage text

    // --- Display options ---
    public boolean showTitle    = true;
    public boolean showBars     = true;
    public boolean showPercent  = true;
    public int maxEntries       = 8;           // Max profiler entries to show

    // --- Corner rounding ---
    public int cornerRadius = 6;

    // --- Border thickness ---
    public int borderThickness = 1;

    public static ModConfig get() {
        return INSTANCE;
    }

    public static void load() {
        if (CONFIG_PATH.toFile().exists()) {
            try (Reader reader = new FileReader(CONFIG_PATH.toFile())) {
                INSTANCE = GSON.fromJson(reader, ModConfig.class);
                if (INSTANCE == null) INSTANCE = new ModConfig();
            } catch (IOException e) {
                INSTANCE = new ModConfig();
            }
        }
    }

    public static void save() {
        try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(INSTANCE, writer);
        } catch (IOException e) {
            com.debugpie.DebugPieMod.LOGGER.error("Failed to save DebugPie config", e);
        }
    }
}
