package com.debugpie.config;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class ConfigScreen extends Screen {

    private final Screen parent;

    // Color field widgets
    private TextFieldWidget bgColorField;
    private TextFieldWidget borderColorField;
    private TextFieldWidget barColorField;
    private TextFieldWidget textColorField;
    private TextFieldWidget titleColorField;
    private TextFieldWidget percentColorField;

    public ConfigScreen(Screen parent) {
        super(Text.literal("DebugPie Config"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int startY = 40;
        int rowH = 24;
        int fieldW = 120;

        // ─── Color fields ───
        bgColorField     = addColorField("BG Color",      cx - 60, startY,            fieldW, colorToHex(ModConfig.get().backgroundColor));
        borderColorField = addColorField("Border Color",  cx - 60, startY + rowH,     fieldW, colorToHex(ModConfig.get().borderColor));
        barColorField    = addColorField("Bar Color",     cx - 60, startY + rowH * 2, fieldW, colorToHex(ModConfig.get().barColor));
        textColorField   = addColorField("Text Color",    cx - 60, startY + rowH * 3, fieldW, colorToHex(ModConfig.get().textColor));
        titleColorField  = addColorField("Title Color",   cx - 60, startY + rowH * 4, fieldW, colorToHex(ModConfig.get().titleColor));
        percentColorField= addColorField("% Color",       cx - 60, startY + rowH * 5, fieldW, colorToHex(ModConfig.get().percentColor));

        // ─── Scale slider ───
        this.addDrawableChild(new SliderWidget(cx - 60, startY + rowH * 6, fieldW, 20,
                Text.literal("Scale: " + String.format("%.1f", ModConfig.get().scale)),
                (ModConfig.get().scale - 0.5f) / 1.5f) {
            @Override
            protected void updateMessage() {
                double v = 0.5 + this.value * 1.5;
                setMessage(Text.literal("Scale: " + String.format("%.1f", v)));
            }
            @Override
            protected void applyValue() {
                ModConfig.get().scale = (float)(0.5 + this.value * 1.5);
            }
        });

        // ─── Max entries slider ───
        this.addDrawableChild(new SliderWidget(cx - 60, startY + rowH * 7, fieldW, 20,
                Text.literal("Max Entries: " + ModConfig.get().maxEntries),
                (ModConfig.get().maxEntries - 3) / 12.0) {
            @Override
            protected void updateMessage() {
                int v = 3 + (int)(this.value * 12);
                setMessage(Text.literal("Max Entries: " + v));
            }
            @Override
            protected void applyValue() {
                ModConfig.get().maxEntries = 3 + (int)(this.value * 12);
            }
        });

        // ─── Toggle: Show bars ───
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Bars: " + (ModConfig.get().showBars ? "ON" : "OFF")),
                btn -> {
                    ModConfig.get().showBars = !ModConfig.get().showBars;
                    btn.setMessage(Text.literal("Bars: " + (ModConfig.get().showBars ? "ON" : "OFF")));
                })
                .dimensions(cx - 60, startY + rowH * 9, 56, 20)
                .build());

        // ─── Toggle: Show % ───
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("% : " + (ModConfig.get().showPercent ? "ON" : "OFF")),
                btn -> {
                    ModConfig.get().showPercent = !ModConfig.get().showPercent;
                    btn.setMessage(Text.literal("% : " + (ModConfig.get().showPercent ? "ON" : "OFF")));
                })
                .dimensions(cx + 4, startY + rowH * 9, 56, 20)
                .build());

        // ─── Save & Close ───
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Save & Close"), btn -> {
            applyColorFields();
            ModConfig.save();
            this.client.setScreen(parent);
        }).dimensions(cx - 60, startY + rowH * 11, 120, 20).build());
    }

    private TextFieldWidget addColorField(String label, int x, int y, int w, String defaultVal) {
        TextFieldWidget field = new TextFieldWidget(this.textRenderer, x, y, w, 18,
                Text.literal(label));
        field.setMaxLength(10);
        field.setText(defaultVal);
        this.addDrawableChild(field);
        return field;
    }

    private void applyColorFields() {
        ModConfig.get().backgroundColor = parseColor(bgColorField.getText(),      ModConfig.get().backgroundColor);
        ModConfig.get().borderColor      = parseColor(borderColorField.getText(),  ModConfig.get().borderColor);
        ModConfig.get().barColor         = parseColor(barColorField.getText(),     ModConfig.get().barColor);
        ModConfig.get().textColor        = parseColor(textColorField.getText(),    ModConfig.get().textColor);
        ModConfig.get().titleColor       = parseColor(titleColorField.getText(),   ModConfig.get().titleColor);
        ModConfig.get().percentColor     = parseColor(percentColorField.getText(), ModConfig.get().percentColor);
    }

    private int parseColor(String hex, int fallback) {
        try {
            String s = hex.startsWith("#") ? hex.substring(1) : hex;
            if (s.startsWith("0x") || s.startsWith("0X")) s = s.substring(2);
            return (int) Long.parseLong(s, 16);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private String colorToHex(int color) {
        return String.format("#%08X", color);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("✦ DebugPie Configuration ✦"), this.width / 2, 14, 0xFF2ECC71);

        // Draw labels next to fields
        int cx = this.width / 2;
        int startY = 40;
        int rowH = 24;
        String[] labels = {"BG Color", "Border Color", "Bar Color", "Text Color", "Title Color", "% Color"};
        for (int i = 0; i < labels.length; i++) {
            context.drawTextWithShadow(this.textRenderer, Text.literal(labels[i]),
                    cx - 60 - this.textRenderer.getWidth(labels[i]) - 4,
                    startY + rowH * i + 5, 0xFFAAAAAA);
        }
        context.drawTextWithShadow(this.textRenderer, Text.literal("Scale"),
                cx - 60 - this.textRenderer.getWidth("Scale") - 4, startY + rowH * 6 + 5, 0xFFAAAAAA);
        context.drawTextWithShadow(this.textRenderer, Text.literal("Entries"),
                cx - 60 - this.textRenderer.getWidth("Entries") - 4, startY + rowH * 7 + 5, 0xFFAAAAAA);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
