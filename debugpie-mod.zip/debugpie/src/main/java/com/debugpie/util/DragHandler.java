package com.debugpie.util;

import com.debugpie.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

/**
 * Handles mouse-based dragging of the overlay panel.
 * Registered via MouseCallback in DebugPieMod.
 */
public class DragHandler {

    private static boolean dragging = false;
    private static double dragStartMouseX = 0;
    private static double dragStartMouseY = 0;
    private static int dragStartPanelX = 0;
    private static int dragStartPanelY = 0;

    public static void onMouseButton(double mouseX, double mouseY, int button, int action) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.overlayVisible) return;

        float scale = cfg.scale;
        int panelX = cfg.posX;
        int panelY = cfg.posY;
        int panelW = (int)(cfg.panelWidth * scale);
        int panelH = 200; // approximate hit zone

        boolean hovered = mouseX >= panelX && mouseX <= panelX + panelW
                && mouseY >= panelY && mouseY <= panelY + panelH;

        // action 1 = press, 0 = release
        if (button == 0) {
            if (action == 1 && hovered) {
                dragging = true;
                dragStartMouseX = mouseX;
                dragStartMouseY = mouseY;
                dragStartPanelX = panelX;
                dragStartPanelY = panelY;
            } else if (action == 0) {
                if (dragging) {
                    ModConfig.save();
                }
                dragging = false;
            }
        }
    }

    public static void onMouseMove(double mouseX, double mouseY) {
        if (!dragging) return;
        ModConfig cfg = ModConfig.get();
        cfg.posX = (int)(dragStartPanelX + (mouseX - dragStartMouseX));
        cfg.posY = (int)(dragStartPanelY + (mouseY - dragStartMouseY));
        // Clamp to screen
        MinecraftClient client = MinecraftClient.getInstance();
        cfg.posX = Math.max(0, Math.min(cfg.posX, client.getWindow().getScaledWidth()  - cfg.panelWidth));
        cfg.posY = Math.max(0, Math.min(cfg.posY, client.getWindow().getScaledHeight() - 100));
    }

    public static boolean isDragging() { return dragging; }
}
