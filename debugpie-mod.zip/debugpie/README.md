# DebugPie 🟩

> A clean, pinnable, color-customizable profiler overlay for Minecraft 1.21.x (Fabric)

DebugPie replaces the chaotic vanilla debug pie chart with a minimal, always-visible overlay
showing only what matters: profiler entry names and their percentages — no pie graphic, no clutter.

---

## ✨ Features

| Feature | Description |
|---|---|
| **Pinned overlay** | Always visible without pressing F3 |
| **Clean list UI** | Name + percentage bar only, no pie chart |
| **Drag to reposition** | Click and drag the panel anywhere on screen |
| **Color customization** | Every color is configurable (background, border, bars, text, %) |
| **Scale control** | Resize the entire overlay freely |
| **Max entries** | Choose how many profiler entries to display (3–15) |
| **Toggle bars / %** | Optional bar and percentage display |
| **Keybindings** | F4 = toggle visibility, F6 = open config screen |
| **Persistent config** | Settings saved to `config/debugpie.json` |

---

## 🚀 Setup & Build

### Requirements
- Java 21+
- Fabric Loader `0.16.5+`
- Fabric API `0.102.0+1.21.1`

### Build
```bash
./gradlew build
```
The output `.jar` will be in `build/libs/`. Drop it in your Minecraft `mods/` folder.

---

## 🎮 Keybindings

| Key | Action |
|---|---|
| `F4` | Toggle overlay on/off |
| `F6` | Open configuration screen |

These can be rebound in **Options → Controls → DebugPie**.

---

## ⚙️ Configuration

Config file: `.minecraft/config/debugpie.json`

```json
{
  "overlayVisible": true,
  "posX": 10,
  "posY": 10,
  "scale": 1.0,
  "panelWidth": 220,
  "backgroundColor": "0xCC0A0A0A",
  "borderColor": "0xFF2ECC71",
  "titleColor": "0xFFFFFFFF",
  "textColor": "0xFFCCCCCC",
  "barColor": "0xFF2ECC71",
  "barBgColor": "0xFF1A1A1A",
  "percentColor": "0xFFFFFFFF",
  "showTitle": true,
  "showBars": true,
  "showPercent": true,
  "maxEntries": 8,
  "cornerRadius": 6,
  "borderThickness": 1
}
```

Colors are in **ARGB hex** format: `0xAARRGGBB`
- `AA` = alpha (FF = fully opaque, 00 = invisible)
- `RR GG BB` = red, green, blue channels

### Example color presets

| Theme | BG | Border | Bar |
|---|---|---|---|
| Default (green) | `0xCC0A0A0A` | `0xFF2ECC71` | `0xFF2ECC71` |
| Blue tech | `0xCC050510` | `0xFF3498DB` | `0xFF3498DB` |
| Amber retro | `0xCC100800` | `0xFFE67E22` | `0xFFE67E22` |
| Pure white | `0xEEFFFFFF` | `0xFF333333` | `0xFF555555` |
| Dracula | `0xDD282a36` | `0xFFBD93F9` | `0xFFBD93F9` |

---

## 🗂 Project Structure

```
debugpie/
├── src/main/java/com/debugpie/
│   ├── DebugPieMod.java          # Entrypoint, keybindings, HUD registration
│   ├── config/
│   │   ├── ModConfig.java        # Config data + load/save
│   │   └── ConfigScreen.java     # In-game config GUI
│   ├── hud/
│   │   └── DebugHudRenderer.java # The overlay renderer
│   ├── mixin/
│   │   └── MouseMixin.java       # Mouse hook for drag support
│   └── util/
│       └── DragHandler.java      # Drag-to-reposition logic
├── src/main/resources/
│   ├── fabric.mod.json
│   ├── debugpie.mixins.json
│   └── assets/debugpie/lang/en_us.json
├── build.gradle
├── gradle.properties
└── settings.gradle
```

---

## 📝 License

MIT — do whatever you want with it.
